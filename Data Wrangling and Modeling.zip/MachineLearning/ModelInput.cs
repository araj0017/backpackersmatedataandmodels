// Create class for input

using Microsoft.ML.Data;

namespace Backpacker.MachineLearning
{
    public class ModelInput
    {
	//ID class with float input
        [ColumnName("Id"), LoadColumn(0)]		
        public float Id { get; set; }


	//Humidity class float input
        [ColumnName("Relative_Humidity_"), LoadColumn(1)]
        public float Relative_Humidity_ { get; set; }

	//Wind speed class with float input
        [ColumnName("Wind_Speed_2m_kmph"), LoadColumn(2)]
        public float Wind_Speed_2m_kmph { get; set; }

	//Pressure class with float input
        [ColumnName("Barometric_Pressure_hPa"), LoadColumn(3)]
        public float Barometric_Pressure_hPa { get; set; }

	//Temperature class with float input
        [ColumnName("Air_temperature_degC"), LoadColumn(4)]
        public float Air_temperature_degC { get; set; }

	//WBGT class with float input
        [ColumnName("WBGT_degC"), LoadColumn(5)]
        public float WBGT_degC { get; set; }


    }
}

// Model Output class

using System;
using Microsoft.ML.Data;

namespace Backpacker.MachineLearning
{
    public class ModelOutput
    {
	// Score class to output.score with float output
        public float Score { get; set; }
    }
}
